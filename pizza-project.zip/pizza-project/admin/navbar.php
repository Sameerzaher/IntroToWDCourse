<nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        <div class="user-img-div">
                            <img src="assets/img/user.png" class="img-thumbnail" />

                            
                        </div>

                    </li>


                    <li>
                        <a class="active-menu" href="index.php"><i class="fa fa-dashboard "></i>Dashboard</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-desktop "></i>Meals <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                                <a href="addmeal.php"><i class="fa fa-toggle-on"></i>Add Meal</a>
                            </li>
                            <li>
                                <a href="Deletemeal.php"><i class="fa fa-bell "></i>Delete Meals</a>
                            </li>
                             <li>
                                <a href="updatemeals.php"><i class="fa fa-circle-o "></i>Update Meals</a>
                            </li>
                            
                           
                        </ul>
                    </li>
                     <li>
                        <a href="#"><i class="fa fa-yelp "></i>Drinks <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                                <a href="invoice.html"><i class="fa fa-coffee"></i>Add Drink</a>
                            </li>
                            <li>
                                <a href="pricing.html"><i class="fa fa-flash "></i>Delete Drink</a>
                            </li>
                            
                           
                        </ul>
                    </li>
                    <li>
                        <a href="table.html"><i class="fa fa-flash "></i>Deserts </a>
                        
                    </li>
                     <li>
                        <a href="#"><i class="fa fa-bicycle "></i>Forms <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                           
                             <li>
                                <a href="form.html"><i class="fa fa-desktop "></i>Add Desert </a>
                            </li>
                             <li>
                                <a href="form-advance.html"><i class="fa fa-code "></i>Delete Desert</a>
                            </li>
                             
                           
                        </ul>
                    
                    <li>
                        <a href="#"><i class="fa fa-sitemap "></i>Users<span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                                <a href="#"><i class="fa fa-bicycle "></i>Add User</a>
                            </li>
                             <li>
                                <a href="#"><i class="fa fa-flask "></i>All Users</a>
                            </li>
                            
                        </ul>
                    </li>
                   
                    <li>
                        <a href="blank.html"><i class="fa fa-square-o "></i>Stock</a>
                    </li>
                </ul>

            </div>

        </nav>